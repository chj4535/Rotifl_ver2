package com.example.prfc.Classes;

public class UserVariables {
}
